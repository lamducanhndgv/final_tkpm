# PTUDW-17TN-Nhom08

## Final project: Sea diamond hotel web application
 
## Update 01 - Static web

* Each page has it name follow the proposal [link](https://xd.adobe.com/view/baa2aba8-5304-4945-40c2-a8cd64161f5b-cc93)

* Bootstrap version: 4.3.1

* JQuery version: 3.2.1

To see the profile or history order, sign in to the website. We have not using database in this version, so you should create an account, this username and password will storage in cache. Sign in to website with the account you registered.


## Team member:

* Dang Tan Tai - 1712237

* Hoang Duc Cong - 1712304
    
* Truong Khac Trieu - 1712838
